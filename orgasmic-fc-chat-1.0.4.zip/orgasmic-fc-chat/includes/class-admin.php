<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

class Orgasmic_Fc_Chat_Admin
{
    public function __construct(
        private Orgasmic_Fc_Chat_Access $access,
        private Orgasmic_Fc_Chat_Repository $repo,
        private Orgasmic_Fc_Chat_Webhook $webhook
    ) {
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_init', [$this, 'settings']);
        add_action('admin_post_orgasmic_fc_chat_test_webhook', [$this, 'handle_test']);
    }

    public function menu(): void
    {
        add_menu_page(
            'ORGASMIC Chat',
            'ORGASMIC Chat',
            'manage_options',
            'orgasmic-fc-chat',
            [$this, 'render_log'],
            'dashicons-format-chat',
            61
        );
        add_submenu_page(
            'orgasmic-fc-chat',
            'Nachrichten',
            'Nachrichten',
            'manage_options',
            'orgasmic-fc-chat',
            [$this, 'render_log']
        );
        add_submenu_page(
            'orgasmic-fc-chat',
            'Einstellungen',
            'Einstellungen',
            'manage_options',
            'orgasmic-fc-chat-settings',
            [$this, 'render_settings']
        );
    }

    public function settings(): void
    {
        $hex = static function ($value): string {
            return sanitize_hex_color((string) $value) ?: '';
        };

        foreach ([
            Orgasmic_Fc_Chat_Install::OPTION_WEBHOOK_URL => 'esc_url_raw',
            Orgasmic_Fc_Chat_Install::OPTION_WEBHOOK_SECRET => 'sanitize_text_field',
            Orgasmic_Fc_Chat_Install::OPTION_SUBTITLE => 'sanitize_textarea_field',
            Orgasmic_Fc_Chat_Install::OPTION_ACCENT => $hex,
            Orgasmic_Fc_Chat_Install::OPTION_COLOR_BG => $hex,
            Orgasmic_Fc_Chat_Install::OPTION_COLOR_TEXT => $hex,
            Orgasmic_Fc_Chat_Install::OPTION_COLOR_CARD => $hex,
            Orgasmic_Fc_Chat_Install::OPTION_COLOR_MINE => $hex,
            Orgasmic_Fc_Chat_Install::OPTION_COLOR_THEIRS => $hex,
        ] as $option => $cb) {
            register_setting('orgasmic_fc_chat', $option, ['sanitize_callback' => $cb]);
        }

        register_setting('orgasmic_fc_chat', Orgasmic_Fc_Chat_Install::OPTION_INCLUDE_BODY, [
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
        ]);
        register_setting('orgasmic_fc_chat', Orgasmic_Fc_Chat_Install::OPTION_INCLUDE_PII, [
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
        ]);
        register_setting('orgasmic_fc_chat', Orgasmic_Fc_Chat_Install::OPTION_POLL_SECONDS, [
            'type' => 'integer',
            'sanitize_callback' => static function ($value): int {
                $value = absint($value);
                return min(30, max(3, $value ?: 6));
            },
        ]);
        register_setting('orgasmic_fc_chat', Orgasmic_Fc_Chat_Install::OPTION_MAX_LENGTH, [
            'type' => 'integer',
            'sanitize_callback' => static function ($value): int {
                $value = absint($value);
                return min(8000, max(200, $value ?: 2000));
            },
        ]);
        register_setting('orgasmic_fc_chat', Orgasmic_Fc_Chat_Install::OPTION_APPEARANCE, [
            'type' => 'string',
            'sanitize_callback' => static function ($value): string {
                $value = sanitize_text_field((string) $value);
                return in_array($value, ['auto', 'light', 'dark'], true) ? $value : 'auto';
            },
        ]);
        register_setting('orgasmic_fc_chat', Orgasmic_Fc_Chat_Install::OPTION_SPACE_MODE, [
            'type' => 'string',
            'sanitize_callback' => static function ($value): string {
                if (is_array($value)) {
                    return in_array('all', $value, true) ? 'all' : 'selected';
                }
                $value = sanitize_text_field((string) $value);
                return $value === 'selected' ? 'selected' : 'all';
            },
        ]);
        register_setting('orgasmic_fc_chat', Orgasmic_Fc_Chat_Install::OPTION_SPACE_IDS, [
            'type' => 'array',
            'sanitize_callback' => static function ($value): array {
                if (!is_array($value)) {
                    return [];
                }
                return array_values(array_unique(array_filter(array_map('intval', $value))));
            },
        ]);
    }

    public function handle_test(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Keine Berechtigung.');
        }
        check_admin_referer('orgasmic_fc_chat_test_webhook');
        $result = $this->webhook->send_test();
        wp_safe_redirect(add_query_arg([
            'page' => 'orgasmic-fc-chat-settings',
            'orgasmic_fc_chat_test' => $result['ok'] ? '1' : '0',
        ], admin_url('admin.php')));
        exit;
    }

    public function render_log(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $spaces = $this->access->space_map();
        echo '<div class="wrap"><h1>ORGASMIC Chat — Nachrichten</h1>';
        echo '<p>Letzte Nachrichten über alle Spaces. Geheime Kreise bleiben im Portal trotzdem nur für Mitglieder sichtbar.</p>';
        echo '<table class="widefat striped"><thead><tr>';
        echo '<th>Zeit (UTC)</th><th>Space</th><th>Mitglied</th><th>Nachricht</th><th>Status</th>';
        echo '</tr></thead><tbody>';

        $rows = $this->repo->recent(80);
        if ($rows === []) {
            echo '<tr><td colspan="5">Noch keine Nachrichten.</td></tr>';
        }
        foreach ($rows as $row) {
            $user = !empty($row['user_id']) ? get_userdata((int) $row['user_id']) : null;
            $preview = (string) $row['body'];
            if ($preview === '' && !empty($row['attachment'])) {
                $preview = '📷 Bild';
            }
            if (function_exists('mb_substr')) {
                $preview = mb_substr($preview, 0, 160);
            } else {
                $preview = substr($preview, 0, 160);
            }
            $space_id = (int) $row['space_id'];
            $space_title = isset($spaces[$space_id]) ? (string) $spaces[$space_id]['title'] : '#' . $space_id;
            echo '<tr>';
            echo '<td>' . esc_html((string) $row['created_at']) . '</td>';
            echo '<td>' . esc_html($space_title) . '</td>';
            echo '<td>' . esc_html($user ? $user->display_name : '—') . '</td>';
            echo '<td>' . esc_html($preview) . '</td>';
            echo '<td>' . (!empty($row['deleted']) ? 'gelöscht' : 'aktiv') . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    }

    public function render_settings(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        echo '<div class="wrap"><h1>ORGASMIC Chat — Einstellungen</h1>';
        if (isset($_GET['orgasmic_fc_chat_test'])) {
            $ok = $_GET['orgasmic_fc_chat_test'] === '1';
            echo '<div class="notice notice-' . ($ok ? 'success' : 'error') . '"><p>';
            echo $ok ? 'Test-Webhook wurde ausgelöst.' : 'Test-Webhook fehlgeschlagen. URL prüfen.';
            echo '</p></div>';
        }

        $settings = Orgasmic_Fc_Chat_Install::portal_settings();
        echo '<form method="post" action="options.php">';
        settings_fields('orgasmic_fc_chat');

        echo '<h2>Spaces mit Chat</h2><table class="form-table" role="presentation">';
        echo '<tr><th>Verfügbarkeit</th><td>';
        echo '<input type="hidden" name="' . esc_attr(Orgasmic_Fc_Chat_Install::OPTION_SPACE_MODE) . '" value="selected" />';
        echo '<label><input type="checkbox" name="' . esc_attr(Orgasmic_Fc_Chat_Install::OPTION_SPACE_MODE) . '" value="all" '
            . checked($settings['space_mode'] !== 'selected', true, false)
            . ' /> Alle Spaces</label>';
        echo '<p class="description">Wenn „Alle Spaces“ aus ist, gilt nur die Liste darunter. Mitglieder sehen weiterhin nur Räume ihrer eigenen Kreise.</p>';
        echo '<fieldset style="margin-top:12px;display:grid;gap:6px">';
        echo '<input type="hidden" name="' . esc_attr(Orgasmic_Fc_Chat_Install::OPTION_SPACE_IDS) . '[]" value="0" />';
        $spaces = $this->access->list_spaces();
        if ($spaces === []) {
            echo '<p>Keine Spaces gefunden. FluentCommunity aktiv?</p>';
        }
        foreach ($spaces as $space) {
            $checked = $settings['space_mode'] !== 'selected' || in_array($space['id'], $settings['space_ids'], true);
            echo '<label><input type="checkbox" name="' . esc_attr(Orgasmic_Fc_Chat_Install::OPTION_SPACE_IDS) . '[]" value="'
                . esc_attr((string) $space['id']) . '"' . checked($checked, true, false) . ' /> '
                . esc_html($space['title'])
                . ($space['privacy'] !== '' ? ' <span class="description">(' . esc_html($space['privacy']) . ')</span>' : '')
                . '</label>';
        }
        echo '</fieldset></td></tr></table>';

        echo '<h2>Portal</h2><table class="form-table" role="presentation">';
        echo '<tr><th>Untertitel / Unterschrift</th><td>';
        echo '<textarea class="large-text" rows="2" name="' . esc_attr(Orgasmic_Fc_Chat_Install::OPTION_SUBTITLE) . '">';
        echo esc_textarea($settings['subtitle']);
        echo '</textarea>';
        echo '<p class="description">Text unter der Überschrift „Chat“. Darf leer bleiben.</p></td></tr>';

        $appearance = $settings['appearance'];
        echo '<tr><th>Erscheinungsbild</th><td><select name="' . esc_attr(Orgasmic_Fc_Chat_Install::OPTION_APPEARANCE) . '">';
        foreach ([
            'auto' => 'Wie FluentCommunity (empfohlen)',
            'light' => 'Hell',
            'dark' => 'Dunkel',
        ] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . selected($appearance, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></td></tr>';
        echo '</table>';

        echo '<h2>Farben</h2>';
        echo '<p class="description">Leer = Automatisch aus dem Erscheinungsbild. Hex-Wert oder Color-Picker.</p>';
        echo '<table class="form-table" role="presentation">';
        $this->color_field('Akzent (Buttons, Badge)', Orgasmic_Fc_Chat_Install::OPTION_ACCENT, $settings['accent'], '#409eff');
        $this->color_field('Hintergrund', Orgasmic_Fc_Chat_Install::OPTION_COLOR_BG, $settings['bg'], '#f4f6f8');
        $this->color_field('Text', Orgasmic_Fc_Chat_Install::OPTION_COLOR_TEXT, $settings['text'], '#1d2327');
        $this->color_field('Karten / Thread', Orgasmic_Fc_Chat_Install::OPTION_COLOR_CARD, $settings['card'], '#ffffff');
        $this->color_field('Eigene Nachrichten', Orgasmic_Fc_Chat_Install::OPTION_COLOR_MINE, $settings['mine'], '#e8f3ff');
        $this->color_field('Andere Nachrichten', Orgasmic_Fc_Chat_Install::OPTION_COLOR_THEIRS, $settings['theirs'], '#ffffff');
        echo '</table>';

        echo '<h2>Verhalten</h2><table class="form-table" role="presentation">';
        echo '<tr><th>Polling (Sekunden)</th><td><input type="number" min="3" max="30" name="'
            . esc_attr(Orgasmic_Fc_Chat_Install::OPTION_POLL_SECONDS) . '" value="'
            . esc_attr((string) $settings['poll_seconds']) . '" />';
        echo '<p class="description">Wie oft das Portal nach neuen Nachrichten fragt. Für die App dieselbe REST-API.</p></td></tr>';

        echo '<tr><th>Max. Textlänge</th><td><input type="number" min="200" max="8000" name="'
            . esc_attr(Orgasmic_Fc_Chat_Install::OPTION_MAX_LENGTH) . '" value="'
            . esc_attr((string) $settings['max_length']) . '" /></td></tr>';
        echo '</table>';

        echo '<h2>Webhook</h2><table class="form-table" role="presentation">';
        echo '<tr><th>Webhook-URL</th><td><input type="url" class="regular-text" name="'
            . esc_attr(Orgasmic_Fc_Chat_Install::OPTION_WEBHOOK_URL) . '" value="'
            . esc_attr((string) get_option(Orgasmic_Fc_Chat_Install::OPTION_WEBHOOK_URL, '')) . '" />';
        echo '<p class="description">Events: <code>chat.message</code>, <code>chat.read</code>, <code>chat.test</code>.</p></td></tr>';

        echo '<tr><th>Webhook-Secret</th><td><input type="text" class="regular-text" name="'
            . esc_attr(Orgasmic_Fc_Chat_Install::OPTION_WEBHOOK_SECRET) . '" value="'
            . esc_attr((string) get_option(Orgasmic_Fc_Chat_Install::OPTION_WEBHOOK_SECRET, '')) . '" />';
        echo '<p class="description">Optional. HMAC-SHA256 in <code>X-Orgasmic-Signature</code>.</p></td></tr>';

        echo '<tr><th>Nachrichtentext</th><td>';
        echo '<input type="hidden" name="' . esc_attr(Orgasmic_Fc_Chat_Install::OPTION_INCLUDE_BODY) . '" value="0" />';
        echo '<label><input type="checkbox" name="' . esc_attr(Orgasmic_Fc_Chat_Install::OPTION_INCLUDE_BODY) . '" value="1" '
            . checked((bool) get_option(Orgasmic_Fc_Chat_Install::OPTION_INCLUDE_BODY, 0), true, false)
            . ' /> Nachrichtentext im Webhook mitschicken</label>';
        echo '<p class="description">Standard aus — nur Metadaten (Space, User, Message-ID).</p></td></tr>';

        echo '<tr><th>Personenbezogene Daten</th><td>';
        echo '<input type="hidden" name="' . esc_attr(Orgasmic_Fc_Chat_Install::OPTION_INCLUDE_PII) . '" value="0" />';
        echo '<label><input type="checkbox" name="' . esc_attr(Orgasmic_Fc_Chat_Install::OPTION_INCLUDE_PII) . '" value="1" '
            . checked((bool) get_option(Orgasmic_Fc_Chat_Install::OPTION_INCLUDE_PII, 1), true, false)
            . ' /> Name und E-Mail im Webhook mitschicken</label></td></tr>';
        echo '</table>';
        submit_button();
        echo '</form>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('orgasmic_fc_chat_test_webhook');
        echo '<input type="hidden" name="action" value="orgasmic_fc_chat_test_webhook" />';
        submit_button('Test-Webhook senden', 'secondary');
        echo '</form>';
        echo $this->color_script();
        echo '</div>';
    }

    private function color_field(string $label, string $option, string $value, string $fallback): void
    {
        $auto = $value === '';
        echo '<tr><th>' . esc_html($label) . '</th><td>';
        echo '<label style="margin-right:10px"><input type="checkbox" class="och-color-auto" data-och-color="'
            . esc_attr($option) . '"' . checked($auto, true, false) . ' /> Automatisch</label>';
        echo '<input type="color" class="och-color-picker" data-och-color="' . esc_attr($option) . '" value="'
            . esc_attr($auto ? $fallback : $value) . '"' . disabled($auto, true, false) . ' /> ';
        echo '<input type="hidden" name="' . esc_attr($option) . '" id="' . esc_attr($option) . '" value="'
            . esc_attr($value) . '" />';
        echo '</td></tr>';
    }

    private function color_script(): string
    {
        return <<<'HTML'
<script>
(function () {
  function sync(name) {
    var auto = document.querySelector('.och-color-auto[data-och-color="' + name + '"]');
    var picker = document.querySelector('.och-color-picker[data-och-color="' + name + '"]');
    var hidden = document.getElementById(name);
    if (!auto || !picker || !hidden) return;
    picker.disabled = auto.checked;
    hidden.value = auto.checked ? '' : picker.value;
  }
  document.querySelectorAll('.och-color-auto').forEach(function (el) {
    el.addEventListener('change', function () { sync(el.getAttribute('data-och-color')); });
  });
  document.querySelectorAll('.och-color-picker').forEach(function (el) {
    el.addEventListener('input', function () { sync(el.getAttribute('data-och-color')); });
  });
})();
</script>
HTML;
    }
}
