<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

class Orgasmic_Fc_Chat_Install
{
    public const DB_VERSION = '1.1.0';
    public const OPTION_DB = 'orgasmic_fc_chat_db';
    public const OPTION_WEBHOOK_URL = 'orgasmic_fc_chat_webhook_url';
    public const OPTION_WEBHOOK_SECRET = 'orgasmic_fc_chat_webhook_secret';
    public const OPTION_INCLUDE_BODY = 'orgasmic_fc_chat_include_body';
    public const OPTION_INCLUDE_PII = 'orgasmic_fc_chat_include_pii';
    public const OPTION_POLL_SECONDS = 'orgasmic_fc_chat_poll_seconds';
    public const OPTION_MAX_LENGTH = 'orgasmic_fc_chat_max_length';
    public const OPTION_SUBTITLE = 'orgasmic_fc_chat_subtitle';
    public const OPTION_APPEARANCE = 'orgasmic_fc_chat_appearance';
    public const OPTION_ACCENT = 'orgasmic_fc_chat_accent';
    public const OPTION_COLOR_BG = 'orgasmic_fc_chat_color_bg';
    public const OPTION_COLOR_TEXT = 'orgasmic_fc_chat_color_text';
    public const OPTION_COLOR_CARD = 'orgasmic_fc_chat_color_card';
    public const OPTION_COLOR_MINE = 'orgasmic_fc_chat_color_mine';
    public const OPTION_COLOR_THEIRS = 'orgasmic_fc_chat_color_theirs';
    public const OPTION_SPACE_MODE = 'orgasmic_fc_chat_space_mode';
    public const OPTION_SPACE_IDS = 'orgasmic_fc_chat_space_ids';
    public const DEFAULT_SUBTITLE = 'Ein Chat pro Kreis — nur für Mitglieder.';

    public static function portal_settings(): array
    {
        $stored_subtitle = get_option(self::OPTION_SUBTITLE, false);
        $subtitle = $stored_subtitle === false ? self::DEFAULT_SUBTITLE : (string) $stored_subtitle;
        $appearance = (string) get_option(self::OPTION_APPEARANCE, 'auto');
        if (!in_array($appearance, ['auto', 'light', 'dark'], true)) {
            $appearance = 'auto';
        }
        $space_mode = (string) get_option(self::OPTION_SPACE_MODE, 'all');
        if (!in_array($space_mode, ['all', 'selected'], true)) {
            $space_mode = 'all';
        }
        $space_ids = get_option(self::OPTION_SPACE_IDS, []);
        if (!is_array($space_ids)) {
            $space_ids = [];
        }
        $space_ids = array_values(array_unique(array_filter(array_map('intval', $space_ids))));
        $poll = (int) get_option(self::OPTION_POLL_SECONDS, 6);
        if ($poll < 3) {
            $poll = 3;
        }
        if ($poll > 30) {
            $poll = 30;
        }
        $max = (int) get_option(self::OPTION_MAX_LENGTH, 2000);
        if ($max < 200) {
            $max = 200;
        }
        if ($max > 8000) {
            $max = 8000;
        }

        return [
            'subtitle' => $subtitle,
            'appearance' => $appearance,
            'accent' => self::color(self::OPTION_ACCENT),
            'bg' => self::color(self::OPTION_COLOR_BG),
            'text' => self::color(self::OPTION_COLOR_TEXT),
            'card' => self::color(self::OPTION_COLOR_CARD),
            'mine' => self::color(self::OPTION_COLOR_MINE),
            'theirs' => self::color(self::OPTION_COLOR_THEIRS),
            'space_mode' => $space_mode,
            'space_ids' => $space_ids,
            'poll_seconds' => $poll,
            'max_length' => $max,
        ];
    }

    public static function color(string $option): string
    {
        return sanitize_hex_color((string) get_option($option, '')) ?: '';
    }

    public static function enabled_space_ids(): ?array
    {
        $settings = self::portal_settings();
        if ($settings['space_mode'] !== 'selected') {
            return null;
        }

        return $settings['space_ids'];
    }

    public static function messages_table(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'orgasmic_fc_chat_messages';
    }

    public static function reads_table(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'orgasmic_fc_chat_reads';
    }

    public function activate(): void
    {
        $this->create_tables();
        $this->ensure_reply_column();
        update_option(self::OPTION_DB, self::DB_VERSION);
        $this->ensure_defaults();
    }

    public function maybe_upgrade(): void
    {
        if (get_option(self::OPTION_DB) !== self::DB_VERSION) {
            $this->create_tables();
            $this->ensure_reply_column();
            update_option(self::OPTION_DB, self::DB_VERSION);
        }
        $this->ensure_defaults();
    }

    private function ensure_reply_column(): void
    {
        global $wpdb;
        $table = self::messages_table();
        $has = $wpdb->get_results("SHOW COLUMNS FROM {$table} LIKE 'reply_to'");
        if ($has) {
            return;
        }
        $wpdb->query("ALTER TABLE {$table} ADD reply_to BIGINT UNSIGNED NOT NULL DEFAULT 0");
    }

    private function ensure_defaults(): void
    {
        if (get_option(self::OPTION_INCLUDE_BODY, null) === null) {
            update_option(self::OPTION_INCLUDE_BODY, 0);
        }
        if (get_option(self::OPTION_INCLUDE_PII, null) === null) {
            update_option(self::OPTION_INCLUDE_PII, 1);
        }
        if (get_option(self::OPTION_POLL_SECONDS, null) === null) {
            update_option(self::OPTION_POLL_SECONDS, 6);
        }
        if (get_option(self::OPTION_MAX_LENGTH, null) === null) {
            update_option(self::OPTION_MAX_LENGTH, 2000);
        }
        if (get_option(self::OPTION_SUBTITLE, null) === null) {
            update_option(self::OPTION_SUBTITLE, self::DEFAULT_SUBTITLE);
        }
        if (get_option(self::OPTION_APPEARANCE, null) === null) {
            update_option(self::OPTION_APPEARANCE, 'auto');
        }
    }

    private function create_tables(): void
    {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();

        $messages = self::messages_table();
        dbDelta("CREATE TABLE {$messages} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            space_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            body TEXT NOT NULL,
            attachment_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            reply_to BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            deleted_at DATETIME NULL,
            PRIMARY KEY  (id),
            KEY space_id_id (space_id, id),
            KEY space_created (space_id, created_at)
        ) {$charset};");

        $reads = self::reads_table();
        dbDelta("CREATE TABLE {$reads} (
            user_id BIGINT UNSIGNED NOT NULL,
            space_id BIGINT UNSIGNED NOT NULL,
            last_read_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            last_read_at DATETIME NOT NULL,
            PRIMARY KEY  (user_id, space_id),
            KEY space_read (space_id, last_read_id)
        ) {$charset};");
    }
}
